package com.myjavablog.model;

public class TextColor {
    // TODO add more attribute later
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
